#include<Windows.h>
#include <stdio.h>
#include <time.h>
#include <tchar.h>
#include <thread>
#include <fcntl.h>
#include <stdlib.h>
#include "shared.h"
#include "info.h"

using namespace shared;

DWORD GameThreadID;
HANDLE GameThreadHandle;
BOOL isGame;

HANDLE eventoJogo;
TCHAR username[25];
TCHAR username1;
TCHAR username2;
Comando comando;

/*void readTChars(TCHAR * p, int maxchars) {
	int len;
	_fgetts(p, maxchars, stdin);
	len = _tcslen(p);
	if (p[len - 1] == TEXT('\n'))
		p[len - 1] = TEXT('\0');
}*/

/*void doLogin() {
	_tprintf(TEXT("\n\tLogin\n"));
	//_fgetts(username, 100, stdin);
	do {
		_tprintf(TEXT("Nome de utilizador: "));
		//readTChars(username, 100);
		//_fgetts(username, 100, stdin);
		//_tscanf_s(TEXT(" %s"), &username);
		//wscanf_s(L"%s", username, 100);
		comando.id = 0;
		comando.tipo = CMD_LOGIN;
		login = TRUE;
	} while (login == FALSE);

	_tprintf(TEXT("Successfully logged in! Welcome %s"), username);

}*/

DWORD WINAPI GameThread(LPVOID param) {

	GameInfo gameInfo;

	isGame = TRUE;

	do {
		ReadGameMemory(&gameInfo);

		_tprintf(TEXT("%s\n"), gameInfo.comand);

	} while (isGame);

	return 0;
}

void initGame() {

	TCHAR wait;
	_tscanf_s(TEXT(" %c"), &wait);
	isGame = FALSE; 
	WaitForSingleObject(GameThreadHandle, INFINITE);
	
}

void getHighScore() {

	Info info;

	_tcscpy_s(info.comand, sizeof(TCHAR[50]), TEXT("highScore"));

	WriteMemory(info);
	ReadMemory(&info);

	for (size_t i = 0; i < 10; i++)
	{
		_tprintf(TEXT("%d - %s\n"), i+1, info.high.users[i].username);
	}
}

void menu() {
	TCHAR choice;
	TCHAR in[100];
	BOOL menu;
	Info info;

	_tprintf(TEXT("\n\tArkanoid\n"));
	_tprintf(TEXT("1 - New Game\n"));
	_tprintf(TEXT("2 - Registry\n"));
	_tprintf(TEXT("3 - Exit\n"));

	//_tscanf_s(TEXT(" %c"), &choice);
	do {

		fflush(stdin);
		_tprintf(TEXT("\nChoice: "));
		_tscanf_s(TEXT(" %c"), &choice);


		if (choice == '1') {

			_tcscpy_s(info.comand, sizeof(TCHAR[50]), TEXT("ccomecar"));
			WriteMemory(info);
			ReadMemory(&info);
			GameThreadHandle = CreateThread(
				NULL,                   // default security attributes
				0,                      // use default stack size  
				GameThread,       // thread function name
				NULL,          // argument to thread function 
				0,                      // use default creation flags 
				&GameThreadID);
			initGame();
		}
		else if (choice == '2') {
			getHighScore();
		}
	} while (choice != '3');

}

void login() {

	//Info info;

	do {

		fflush(stdin);
		_tprintf(TEXT("Nome de utilizador: "));
		_fgetts(username, 25, stdin);
		//_tcscpy_s(info.usename, sizeof(username), username);
		//_tprintf(TEXT("Successfully logged in! Welcome %s"), username);
		//WriteMemory(info);
		//ReadMemory(&info);
	} while (_tcsncmp(username, TEXT("login"), 5));
	
}

int _tmain(int argc, char* argv[]){



	if (!OpenSharedMemory()) {
		_tprintf(TEXT("shit went wrong opening shared memory\n"));
	}
	else {
		_tprintf(TEXT("Everything is ok mate\n"));
	}

	if (!OpenSync()) {
		_tprintf(TEXT("shit went wrong opening semaphores\n"));
	}
	else {
		_tprintf(TEXT("Green light mate\n"));
	} 


	login();

	menu();

	return 32;
}