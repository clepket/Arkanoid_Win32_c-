#include<Windows.h>
#include<io.h>
#include <stdio.h>
#include <time.h>
#include <tchar.h>
#include <thread>
#include <fcntl.h>
#include <tchar.h>
#include <stdlib.h>
#include "shared.h"
#include "main.h"

using namespace shared;
HighScores hs;
BOOL isShutdown;

Info info[25];


void TakeAction(Info *info) {
	if (_tcsncmp(info->comand, TEXT("comecar"), 7))
	{

	}
	else if (_tcscmp(info->comand, TEXT("highScore")), 9)
	{
		Info info;

		info.high = hs;
			
	}
}

DWORD WINAPI LobbyThread(LPVOID param) {
	Info info;

	do {
		ReadMemory(&info);
		TakeAction(&info);
		WriteMemory(info);
	} while (isShutdown);
	return 0;
}


DWORD WINAPI GameThread(LPVOID param) {
	GameInfo gameInfo;
	_tcscpy_s(gameInfo.comand, sizeof(TCHAR[50]), TEXT(" 0 2"));
	do {
		WriteGameMemory(gameInfo);

		_tprintf(TEXT("%s\n"), gameInfo.comand);


	} while (isShutdown && gameInfo.isGame);
	return 0;
}

/*void createReg() {
	RegCreateKeyEx(HKEY_CURRENT_USER, REGKEY, 0, NULL, REG_OPTION_NON_VOLATILE, KEY_ALL_ACCESS, NULL, &handleKey, NULL);

	if (RegCloseKey(handleKey) == ERROR_SUCCESS) {
		_tprintf(TEXT("\nKey closed successfully\n"));
	}x
	else
		_tprintf(TEXT("\nError closing key\n"));
}*/

void writeReg() {
	if (RegCreateKeyEx(HKEY_CURRENT_USER, REGKEY, 0, NULL, REG_OPTION_NON_VOLATILE, KEY_ALL_ACCESS, NULL, &handleKey, NULL) == ERROR_SUCCESS)
		_tprintf(TEXT("\nKey opened successfully\n"));
	else
		_tprintf(TEXT("\nError opening key\n"));

	if (RegSetValueEx(handleKey, v, 0, REG_SZ, (LPBYTE)& hs, sizeof(HighScores)) == ERROR_SUCCESS)
		_tprintf(TEXT("\nWriting to registry\n"));
	else
		_tprintf(TEXT("\nError writing\n"));

	if (RegCloseKey(handleKey))
		_tprintf(TEXT("\nKey closed successfully\n"));
}

void readReg() {
	if (RegOpenKeyEx(HKEY_CURRENT_USER, (LPWSTR)REGKEY, 0, KEY_ALL_ACCESS, &handleKey) == ERROR_SUCCESS)
		_tprintf(TEXT("\nSuccess\n"));
	else
		_tprintf(TEXT("\nError\n"));

	DWORD size = sizeof(HighScores);

	RegGetValue(HKEY_CURRENT_USER, REGKEY, v, RRF_RT_ANY, NULL, (PVOID)& hs, &size);
	
	if (RegCloseKey(handleKey) == ERROR_SUCCESS)
		_tprintf(TEXT("\nKey closed successfully\n"));
	else
		_tprintf(TEXT("\nError closing key\n"));

}

void initReg() {
	swprintf_s(hs.users[0].username, TEXT("Diogo"));
	swprintf_s(hs.users[1].username, TEXT("Carlos"));
	swprintf_s(hs.users[2].username, TEXT("Andr�"));
	swprintf_s(hs.users[3].username, TEXT("Jos�"));
	swprintf_s(hs.users[4].username, TEXT("Ant�nio"));
	swprintf_s(hs.users[5].username, TEXT("Jo�o"));
	swprintf_s(hs.users[6].username, TEXT("Bruno"));
	swprintf_s(hs.users[7].username, TEXT("Afonso"));
	swprintf_s(hs.users[8].username, TEXT("Dinis"));
	swprintf_s(hs.users[9].username, TEXT("Tiago"));

	writeReg();
	readReg();
	
	for (int i = 0; i < 10; i++) {
		_tprintf(TEXT("%d - %s\n"), i + 1, hs.users[i].username);
	}
	system("pause");
}

int _tmain(int argc, char* argv[])
{

	DWORD LobbyThreadID, GameThreadID;
	HANDLE LobbyThreadHandle, GameThreadHandle;
	TCHAR input[100] = {};

	isShutdown = TRUE;

#ifdef UNICODE
	_setmode(_fileno(stdin), _O_WTEXT);
	_setmode(_fileno(stdout), _O_WTEXT);
#endif

	if (!InitSharedMemory())
	{
		_tprintf(TEXT("Erro ao montar memoria partilhada, a sair...\n"));
		return 50;
	}
	else
	{
		_tprintf(TEXT("Memoria partilhada ok...\nA iniciar lobby..."));
	}
	if (!InitSync())
	{
		_tprintf(TEXT("Erro ao iniciar sincroniza��o...\n"));
		return 1;
	}
	else
	{
		_tprintf(TEXT("Sincroniza��o ok...\nA iniciar lobby..."));
	}

	initReg();
	
	LobbyThreadHandle = CreateThread(
		NULL,                   // default security attributes
		0,                      // use default stack size  
		LobbyThread,       // thread function name
		NULL,          // argument to thread function 
		0,                      // use default creation flags 
		&LobbyThreadID);   // returns the thread identifier 




	do{
		//processar teclado
		//fflush(stdin);
		_fgetts(input, 100, stdin);
		//_tscanf_s(TEXT(" %s"), &input);
		//input[_tcslen(input) - 1] = 0;


		if ((_tcsncmp(input, TEXT("login"), 5)))
		{
			GameThreadHandle = CreateThread(
				NULL,                   // default security attributes
				0,                      // use default stack size  
				GameThread,       // thread function name
				NULL,          // argument to thread function 
				0,                      // use default creation flags 
				&GameThreadID);   // returns the thread identifier 

		} else if ((_tcscmp(input, TEXT("le")) == 0))
		{
			//Info info = ReadMemory();
			
		}
		else if ((_tcscmp(input, TEXT("escreve")) == 0))
		{
			
			_tprintf(TEXT("\n 1"));
		}
	}while (_tcsncmp(input, TEXT("sair"), 4));

	isShutdown = FALSE;
	WaitForSingleObject(LobbyThreadHandle, INFINITE);
	WaitForSingleObject(GameThreadHandle, INFINITE);
}