#pragma once


#include<Windows.h>
#include<io.h>
#include <stdio.h>
#include <time.h>
#include <tchar.h>
#include <thread>
#include <fcntl.h>
#include <tchar.h>
#include <stdlib.h>



#define PAGE_NAME "ARKANOIDSERV"
#define PAGESIZE 1024*1024*8 //Mbyte
#define WRITESEMAPHORE "writeSemaphore"
#define READSEMAPHORE "readSemaphore"
#define PAGE_GAME "ARKANOIDGAME"
#define PAGESIZE 1024*1024*8 //Mbyte
#define WRITEGAMESEMAPHORE "writeGameSemaphore"
#define READSGAMESEMAPHORE "readGameSemaphore"


#define COMAND "comand"

#define BUFFER 10
#define BUFFERSIZE 1
#define CMD_LOGIN 5
#define REGKEY TEXT("ARKANOID")
#define MAX_REG 10



TCHAR writeSemaphore[] = TEXT("writeSemaphore");
TCHAR readSemaphore[] = TEXT("readSemaphore");
TCHAR writeMutex[] = TEXT("writeMutex");
TCHAR readMutex[] = TEXT("readMutex");
TCHAR writeGameSemaphore[] = TEXT("writeGameSemaphore");
TCHAR readGameSemaphore[] = TEXT("readGameSemaphore");
TCHAR writeGameMutex[] = TEXT("writeGameMutex");
TCHAR readGameMutex[] = TEXT("readGameMutex");
HKEY handleKey;
LPCTSTR v = TEXT("High Scores");
