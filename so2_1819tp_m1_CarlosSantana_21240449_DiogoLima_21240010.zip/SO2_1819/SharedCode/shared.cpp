#include "shared.h"
#include "info.h"

namespace shared {

	MemoryS servMemory;
	MemoryS gameMemory;

	Info(*pMemory)[BUFFER][BUFFERSIZE];
	GameInfo(*pGameMemory)[BUFFER][BUFFERSIZE];

	bool InitSharedMemory() {
		servMemory.hPage = CreateFileMapping(
			INVALID_HANDLE_VALUE,
			NULL,
			PAGE_READWRITE,
			0,
			PAGESIZE,
			TEXT(PAGE_NAME)
		);

		if (servMemory.hPage == NULL)
			return FALSE;

		pMemory = (Info(*)[BUFFER][BUFFERSIZE])MapViewOfFile(servMemory.hPage
			, FILE_MAP_WRITE, 0, 0, sizeof(Info[BUFFER][BUFFERSIZE]));

		if (pMemory == NULL)
			return FALSE;

		gameMemory.hPage = CreateFileMapping(
			INVALID_HANDLE_VALUE,
			NULL,
			PAGE_READWRITE,
			0,
			PAGESIZE,
			TEXT(PAGE_GAME)
		);

		if (gameMemory.hPage == NULL)
			return FALSE;

		pGameMemory = (GameInfo(*)[BUFFER][BUFFERSIZE])MapViewOfFile(gameMemory.hPage
			, FILE_MAP_READ, 0, 0, sizeof(GameInfo[BUFFER][BUFFERSIZE]));


		if (pGameMemory == NULL)
			return FALSE;

		return TRUE;
	}

	bool OpenSharedMemory() {
		servMemory.hPage = OpenFileMapping(FILE_MAP_WRITE, TRUE, TEXT(PAGE_NAME));
		
		if (servMemory.hPage == NULL)
			return FALSE;

		pMemory = (Info(*)[BUFFER][BUFFERSIZE])MapViewOfFile(servMemory.hPage
			, FILE_MAP_WRITE, 0, 0, sizeof(Info[BUFFER][BUFFERSIZE]));


		if (pMemory == NULL)
			return FALSE;

		gameMemory.hPage = OpenFileMapping(FILE_MAP_READ, TRUE, TEXT(PAGE_GAME));

		if (gameMemory.hPage == NULL)
			return FALSE;
		else
			printf("helllooooooo\n");

		pGameMemory = (GameInfo(*)[BUFFER][BUFFERSIZE])MapViewOfFile(gameMemory.hPage
			, FILE_MAP_READ, 0, 0, sizeof(GameInfo[BUFFER][BUFFERSIZE]));


		if (pGameMemory == NULL)
			return FALSE;
		
		return TRUE;
	}


	bool InitSync() {
		servMemory.hWriteSemaphore = CreateSemaphore(NULL, 1000, 1000, writeSemaphore);
		if (servMemory.hWriteSemaphore == NULL) {
			_tprintf(TEXT("O semaforo de leitura falhou\n"));
			return FALSE;
		}

		servMemory.hReadSemaphore = CreateSemaphore(NULL, 0, BUFFER, readSemaphore);
		if (servMemory.hReadSemaphore == NULL) {
			_tprintf(TEXT("O semaforo de leitura falhou\n"));
			return FALSE;
		}

		servMemory.hReadMutex = CreateMutex(NULL, FALSE, readMutex);
		if (servMemory.hReadMutex == NULL) {
			_tprintf(TEXT("O mutex de leitura falhou\n"));
			return FALSE;
		}

		servMemory.hWriteMutex = CreateMutex(NULL, FALSE, writeMutex);
		if (servMemory.hWriteMutex == NULL) {
			_tprintf(TEXT("O mutex de escrita falhou\n"));
			return FALSE;
		}

		gameMemory.hWriteSemaphore = CreateSemaphore(NULL, 1000, 1000, writeGameSemaphore);
		if (gameMemory.hWriteSemaphore == NULL) {
			_tprintf(TEXT("O semaforo de leitura falhou\n"));
			return FALSE;
		}

		gameMemory.hReadSemaphore = CreateSemaphore(NULL, 0, BUFFER, readGameSemaphore);
		if (gameMemory.hReadSemaphore == NULL) {
			_tprintf(TEXT("O semaforo de leitura falhou\n"));
			return FALSE;
		}

		gameMemory.hReadMutex = CreateMutex(NULL, FALSE, readGameMutex);
		if (gameMemory.hReadMutex == NULL) {
			_tprintf(TEXT("O mutex de leitura falhou\n"));
			return FALSE;
		}

		gameMemory.hWriteMutex = CreateMutex(NULL, FALSE, writeGameMutex);
		if (gameMemory.hWriteMutex == NULL) {
			_tprintf(TEXT("O mutex de escrita falhou\n"));
			return FALSE;
		}

		return TRUE;
	}

	bool OpenSync() {
		servMemory.hWriteSemaphore = OpenSemaphore(SYNCHRONIZE, FALSE, writeSemaphore);
		if (servMemory.hWriteSemaphore == NULL) {
			_tprintf(TEXT("O semaforo de escrita falhou\n"));
			return FALSE;
		}

		servMemory.hReadSemaphore = OpenSemaphore(SYNCHRONIZE, FALSE, readSemaphore);
		if (servMemory.hReadSemaphore == NULL) {
			_tprintf(TEXT("O semaforo de leitura falhou\n"));
			return FALSE;
		}

		servMemory.hReadMutex = OpenMutex(SYNCHRONIZE, FALSE, readMutex);
		if (servMemory.hReadMutex == NULL) {
			_tprintf(TEXT("O mutex de leitura falhou\n"));
			return FALSE;
		}

		servMemory.hWriteMutex = OpenMutex(SYNCHRONIZE, FALSE, writeMutex);
		if (servMemory.hWriteMutex == NULL) {
			_tprintf(TEXT("O mutex de escrita falhou\n"));
			return FALSE;
		}

		gameMemory.hWriteSemaphore = OpenSemaphore(SYNCHRONIZE, FALSE, writeSemaphore);
		if (gameMemory.hWriteSemaphore == NULL) {
			_tprintf(TEXT("O semaforo de escrita falhou\n"));
			return FALSE;
		}

		gameMemory.hReadSemaphore = OpenSemaphore(SYNCHRONIZE, FALSE, readSemaphore);
		if (gameMemory.hReadSemaphore == NULL) {
			_tprintf(TEXT("O semaforo de leitura falhou\n"));
			return FALSE;
		}

		gameMemory.hReadMutex = OpenMutex(SYNCHRONIZE, FALSE, readMutex);
		if (gameMemory.hReadMutex == NULL) {
			_tprintf(TEXT("O mutex de leitura falhou\n"));
			return FALSE;
		}

		gameMemory.hWriteMutex = OpenMutex(SYNCHRONIZE, FALSE, writeMutex);
		if (gameMemory.hWriteMutex == NULL) {
			_tprintf(TEXT("O mutex de escrita falhou\n"));
			return FALSE;
		}

		return TRUE;
	}

	void ReadMemory(Info *info) {
		
		WaitForSingleObject(servMemory.hReadSemaphore, INFINITE);
		WaitForSingleObject(servMemory.hReadMutex, INFINITE);
		
		servMemory.pRead = servMemory.posRead;
		servMemory.posRead = (servMemory.posRead + 1) % BUFFER;

		CopyMemory(info, (*pMemory)[servMemory.pRead], sizeof(Info));

		ReleaseMutex(servMemory.hReadMutex);
		ReleaseSemaphore(servMemory.hWriteSemaphore, 1, NULL);

	}

	void ReadGameMemory(GameInfo * gameInfo)
	{
		WaitForSingleObject(gameMemory.hReadSemaphore, INFINITE);
		WaitForSingleObject(gameMemory.hReadMutex, INFINITE);

		gameMemory.pRead = gameMemory.posRead;
		gameMemory.posRead = (gameMemory.posRead + 1) % BUFFER;

		CopyMemory(gameInfo, (*pMemory)[gameMemory.pRead], sizeof(gameInfo));

		ReleaseMutex(gameMemory.hReadMutex);
		ReleaseSemaphore(gameMemory.hWriteSemaphore, 1, NULL);

	}


	void WriteMemory(Info info) {
		
		WaitForSingleObject(servMemory.hWriteSemaphore, INFINITE);
		WaitForSingleObject(servMemory.hWriteMutex, INFINITE);

		servMemory.pWrite = servMemory.posWrite;
		servMemory.posWrite = (servMemory.posWrite + 1) % BUFFER;

		CopyMemory( (*pMemory)[servMemory.pWrite], &info, sizeof(Info));


		ReleaseMutex(servMemory.hWriteMutex);
		ReleaseSemaphore(servMemory.hReadSemaphore, 1, NULL);

	}
	

	void WriteGameMemory(GameInfo gameInfo) {

		WaitForSingleObject(gameMemory.hWriteSemaphore, INFINITE);
		WaitForSingleObject(gameMemory.hWriteMutex, INFINITE);

		gameMemory.pWrite = gameMemory.posWrite;
		gameMemory.posWrite = (gameMemory.posWrite + 1) % BUFFER;


		CopyMemory((*pMemory)[gameMemory.pWrite], &gameInfo, sizeof(gameInfo));


		ReleaseMutex(gameMemory.hWriteMutex);
		ReleaseSemaphore(gameMemory.hReadSemaphore, 1, NULL);

	}
}
